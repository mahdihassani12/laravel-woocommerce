@extends('backend.layouts.app')
@section('main_content')
  <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
    {{trans('labels.add_product')}}
      </h1>
    </section>

     <section class="content">

        <form action="{{ route('products.update',$data['product']->id) }}"   method="post" enctype="multipart/form-data" style="background: #fff; border-radius: 5px; padding:10px;">
          @csrf
           @method('PUT')
            <div class="form-group">
              <label>{{ trans('labels.name') }}</label>
              <input type="text" name="name" placeholder="{{ trans('labels.name') }}" class="form-control" required="required" value="{{$data['product']->name}}">
              <input type="hidden" name="pr_id" value="{{$data['product']->id}}">
            </div>

         <div class="row">
          <div class="col-md-9  margin-bottom-8">
            <div class="form-group">
             <textarea class="form-control summernote" cols="33" name="long_desc" rows="4" required="required"> {{$data['product']->long_desc}}</textarea>
            </div>
            <div class="form-group">
              <label>{{ trans('labels.short_description') }}</label>
              <textarea class="form-control"  name="short_desc" rows="4" required="required">{{$data['product']->short_desc}} </textarea>
            </div>

             <div class="form-group">          
               <label>{{ trans('labels.guide_file') }} <span class="text-danger" style="font-size: 11px">{{trans('labels.leave_empty_f')}}</span></label>
               <input type="file" class="form-control" name="guide_file">
            </div>
              <div class="row">
                  <?php 
                       $gallery=explode('|',$data['product']->gallery);
                       foreach($gallery as $gl):
                          ?>
                         <div class="col-md-1" style="padding: 2px;position: relative; margin:2px; ">
                           <img src="{{asset('uploads/gallery')}}/{{$gl}}" style="max-width: 100%; ;">
                           <span  class="remove_image_gallery" img="{{$gl}}" pr_id="{{$data['product']->id}}">&times; </span>
                         </div>

                      <?php    
                       endforeach; 
                   ?>
              </div>
              <div class="form-group gallery_section">          
                <label>{{ trans('labels.gallery') }} <span class="text-danger">{{trans('labels.more_photo_in_gallery')}}</span></label>
                <input type="file" class="form-control" name="gallery[]" multiple="multiple" id="gallery">
             </div>

          </div>
          
          <div class="col-md-3"> 

           <div class="form-group">
             <label for="product_code">{{ trans('labels.product_code') }}</label>
             <input type="number"  class="form-control" name="product_code" id="product_code" required="required"  value="{{$data['product']->product_code}}">
          </div> 
             
          <div class="form-group">         
            <label>{{ trans('labels.categories') }}</label>
             <select class="select2 " name="category" style="width: 100%;" required="required">
               @foreach($data['category'] as $category)
              <option value="{{ $category->id }}" @if($data['product']->category_id==$category->id) selected  @endif>{{ $category->name }}</option>
               @endforeach
              </select>
          </div>
         
         <div class="form-group">
           <label>{{ trans('labels.unit') }}</label>
           <select class="select2 "  name="unit" style="width: 100%;" required="required">
            @foreach($data['unit'] as $unit)
            <option value="{{ $unit->id }}"  @if($data['product']->unit_id==$unit->id) selected  @endif>{{ $unit->name }}</option>
            @endforeach
           </select>
         </div>
         
         <div class="form-group">
            <label for="qty">{{trans('labels.qty')}}</label>
            <input type="number" name="qty" id="qty" class="form-control" value="{{$data['product']->qty}}">
         </div>

         <div class="col-md-6" style="padding:0px 3px 10px">
            <label for="price">{{trans('labels.price')}}</label>
            <input type="number" id="price" name="price" class="form-control" required="required" value="{{$data['product']->price}}">
         </div>

         <div class="col-md-6" style="padding:0px 3px 10px">
            <label for="old_price">{{trans('labels.old_price')}}</label>
            <input type="number" id="old_price" name="old_price" class="form-control" value="{{$data['product']->old_price}}">
         </div>

           <div class="more_price_area form-group" style="margin-top: 13px;">

                <?php 
                    $morePrice= explode(",", $data['product']->more_price);
                    foreach ($morePrice as $mp) {
                      $price=explode(":", $mp)[0];
                      $qty=explode(":", $mp)[1];
                 ?>
              <div class="more_price_feilds">
                 <div class="row sing_price_row" style="margin-top:5px">
                  <div class="col-md-5" style='padding:0px 2px'>
                     <input type="number" name="mqty[]" class="qty form-control" placeholder="{{trans('labels.qty')}}" value="{{$qty}}">
                  </div>

                  <div class="col-md-5" style='padding:0px 2px'>
                     <input type="number" name="mprice[]" class="price form-control"  placeholder="{{trans('labels.price')}}" value="{{$price}}">
                  </div>
                  <div class="col-md-2" style='padding:0px 2px'>
                     <button type="button" class="btn btn-danger delete_price_row" class='padding:3'>&times;</button>
                  </div>
                </div> 
              </div>
              <?php } ?>
              <button type="button" class="btn btn-success add_new_value" style="margin-top: 10px;">{{trans('labels.new_value')}} <span class="fa fa-plus"></span> </button>
            </div>

          <div class="form-group">          
            <label>{{ trans('labels.featured_image') }} <span class="text-danger" style="font-size: 11px;">{{trans('labels.leave_empty')}}</span></label>
            <input type="file" class="form-control" name="featured_image" id="featured_image" >
         </div>
         
        

         <div class="form-group">
            <button type="submit" class=" btn btn-primary " id="sendEmail">{{ trans('labels.save') }}
                    <i class="fa fa-arrow-circle-left"></i></button>
         </div>
       </div>
       </div>
        </form> 
       
      </section>
  @include('backend.includes.message')
@endsection

@section('style')
  <style>
     .gallery_section .krajee-default.file-preview-frame{
        max-width: 20%;
     }
     .remove_image_gallery{
        background: #00000073;
        position: absolute;
        top: 4px;
        padding: 0px 5px;
        cursor: pointer;
        left: 0px;
        font-weight: bold;
        font-size: 41px;
        bottom: 0px;
        right: 0px;
        text-align: center;
        color: red;
     }
  </style>
@endsection

@section('script')
<script type="text/javascript">
var APP_URL = {!! json_encode(url('/')) !!}

$(document).on("click",".remove_image_gallery", function(){
    var con=confirm('{{trans("msg.are_you_sure")}}');
    if(con==true){
       var img=$(this).attr("img");
       var pid=$(this).attr("pr_id");

      var removeLocation=$(this).parents('.col-md-1');
      $.ajax({
        type:'get',
        url:APP_URL+'/product/delete_gallery_photo?image='+img+'&pid='+pid,
        success:function(response){
          if(response==1){
            removeLocation.remove();
          }
        }
      })
    }
})

    $(document).on("click",".add_new_value",function(){
      var morefield=` <div class="row sing_price_row" style="margin-top:5px">
          <div class="col-md-5" style='padding:0px 2px'>
             <input type="number" name="mqty[]" class="qty form-control" placeholder="{{trans('labels.qty')}}">
          </div>

          <div class="col-md-5" style='padding:0px 2px'>
             <input type="number" name="mprice[]" class="price form-control"  placeholder="{{trans('labels.price')}}">
          </div>
          <div class="col-md-2" style='padding:0px 2px'>
             <button type="button" class="btn btn-danger delete_price_row" class='padding:3'>&times;</button>
          </div>
        </div> 
      `;


var values=$(".more_price_area .more_price_feilds .row");
if(values.length<3){
  var price=$('.more_price_area .more_price_feilds .row:last input.price').val();
  var qty=$('.more_price_area .more_price_feilds .row:last input.qty').val();
    if(price==""){
       $('.more_price_area .more_price_feilds .row:last input.price').css('border','1px solid red');
    } 
    if(qty==""){
      $('.more_price_area .more_price_feilds .row:last input.qty').css('border','1px solid red');
    } 
    else{
       $(".more_price_area .more_price_feilds").append(morefield);
       $('.more_price_area .more_price_feilds .row input').css('border-color','#d2d6de');
       }
  }
})


    $(document).on("click",".delete_price_row",function(){
      $(this).parents('.sing_price_row').remove();
      
    })

     $("#gallery").fileinput({
        theme: 'fas',
        language: 'fa',
        uploadUrl: '#', // you must set a valid URL here else you will get an error
        allowedFileExtensions: ['jpg', 'png', 'gif','jpeg'],
        overwriteInitial: false,
        maxFileSize: 1000,
        //maxFilesNum: 10,
        //allowedFileTypes: ['image', 'video', 'flash'],
        slugCallback: function (filename) {
            return filename.replace('(', '_').replace(']', '_');
        }
    });

        $("#featured_image").fileinput({
        theme: 'fas',
        language: 'fa',
        uploadUrl: '#', // you must set a valid URL here else you will get an error
        allowedFileExtensions: ['jpg', 'png', 'gif','jpeg'],
        overwriteInitial: false,
        maxFileSize: 1000,
        //maxFilesNum: 10,
        //allowedFileTypes: ['image', 'video', 'flash'],
        slugCallback: function (filename) {
            return filename.replace('(', '_').replace(']', '_');
        }
    });

</script>
@endsection

