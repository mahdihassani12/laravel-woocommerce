<?php
return [
'login' => 'Login',
'email_address' => 'E-Mail Address',
'password' => 'Password',
'remember_me' => 'Remember Me',
'register' => 'Register',
'logout' => 'Logout',
'home' => 'Home',
'welcome_to_system' => 'Welcome',
'my_account' => 'My Account',
'dashboard' => 'Dashboard',


];
?>