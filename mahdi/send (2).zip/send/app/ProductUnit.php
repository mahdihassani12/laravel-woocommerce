<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class ProductUnit extends Model
{
    protected $table="tbl_product_unit";
	
}
