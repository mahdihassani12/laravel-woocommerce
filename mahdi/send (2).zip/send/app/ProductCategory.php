<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class ProductCategory extends Model
{
    protected $table="tbl_product_category";
}
