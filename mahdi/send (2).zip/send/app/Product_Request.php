<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_Request extends Model
{
    protected $table = 'tb_product_request';
}
