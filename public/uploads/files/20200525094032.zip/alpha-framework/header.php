<!DOCTYPE html>
<html>

<?php
$favicon=IMAGES.'/icons/favicon.png';
$touchicon=IMAGES.'/icons/touchicon.png';
?>

  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php wp_title('|',true,'right'); bloginfo('name');?></title>
    <meta name="description" content="<?php bloginfo('description');?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <link rel="shortcut icon" href="<?php echo $favicon; ?>">
    <link rel="apple-touch-icon-precomposed" sizes="150x150" href="<?php echo $touchicon; ?>">
    <?php wp_head();?>
  </head>
  <body class="<?php body_class(); ?>">
    <header class="site-header" role="banner">
         <div class="container header-contents">
            <div class="row">
              <div class="col-xs-3">
                  <div class="site-logo">
                      <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">home</a>
                  </div>
              </div>
              <div class="col-xs-9">
                  <nav class="site-navigation" role="navigation">
                      <?php
                        wp_nav_menu(
                          array(
                            'theme_location'=>"main-menu",
                            'menu_class'=>"site-menu"
                          )
                        );
                       ?>
                  </nav>
              </div>
            </div>
         </div>
    </header>
    <div class="container">
      <div class="row">
