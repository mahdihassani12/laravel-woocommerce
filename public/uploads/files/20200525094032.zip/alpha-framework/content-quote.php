<?php

  // default template for displaying post with link format

 ?>
<article id="post-<?php the_id();?>" <?php post_class();?> >
  <div class="entry-content">
    <?php
		the_content(__('Continue reading $rarr','alpha'));
		wp_link_pages();
	?>
  </div>
  
  <footer class="entry-footer">
     <p class="entry-meta">
       <?php alpha_post_meta()?>
     </p>
  
  </footer>
</article>
