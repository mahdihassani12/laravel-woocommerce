<?php

  // default template for displaying post with image post format

 ?>
<article id="post-<?php the_id();?>" <?php post_class();?> >
  <header class="entry-header">

   <?php
     // if single page, display the title
    // else, display the title in a link

   if(is_single()):
   ?>
     <h1><?php the_title(); ?> </h1>
<?php  else:?>
  <h1><a href="<?php the_permalink();?>" rel="bookmark"><?php the_title();?></a></h1>
<?php
 endif;
  ?>


  <p class="entry-meta">
    <?php alpha_post_meta()?>

  </p>
  </header>
  <div class="entry-content">
    <?php
		  the_content(__('Continue reading $rarr','alpha'));
		  wp_link_pages();
	?>
  </div>

  <footer class="entry-footer">
     <?php
	   if(is_single()){
		   echo "<h2>".__('Writteb by ','alpha').get_the_author()."</h2>";
		   if( get_the_author_meta('description')){
			   echo "<p>".the_author_meta('description')."</p>";
		   }
	   }
	 ?>
  </footer>
</article>
