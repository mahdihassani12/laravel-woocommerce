

<?php
get_header();
 ?>
   <h1> <?php _e('Error 404 - Nothing Found','alpha'); ?></h1>

    <p><?php e_('It looks link nothing found. Maybe try a search') ?></p>

    <?php get_search_form(); ?>

 <?php
 get_footer();
  ?>
