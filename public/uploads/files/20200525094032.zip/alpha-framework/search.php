

<!-- the main template file -->
<?php get_header();?>
<div class="main-content col-md-8" role="main">
  <?php if(have_posts()): ?>
   <header>
       <h1>
          <?php
            printf(__('Search Result for %s','alpha'),get_search_query());
           ?>
       </h1>

        <?php rewind_posts(); ?>
   </header>
  <?php
      while(have_posts()): the_post();
        get_template_part('content',get_post_format());
     endwhile;
  ?>
  <?php
  alpha_paging_nav();
  ?>
  <?php else:?>

  <?php get_template_part('content','none');?>
  <?php
  endif;
   ?>
 </div>
<?php get_sidebar();?>


<?php get_footer();?>
