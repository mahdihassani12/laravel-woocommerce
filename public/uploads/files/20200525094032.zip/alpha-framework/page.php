

<?php get_header(); ?>

<div class="main-content col-md-8" role="main">
   <?php while(have_posts()):the_post();?>
      <article <?php post_class();?> id="post-<?php the_ID();?>">
        <header class="entry-header">
          <?php if(has_post_thumbnail() && ! post_password_required()): ?>

            <figure class="entry-thumbnail">
                <?php the_post_thumbnail(); ?>
            </figure>
          <?php endif;?>
           <h1><?php the_title(); ?> </h1>
        </header>
        <div class="entry-content">
          <?php
          the_content();
          wp_link_pages();
       ?>
        </div>

        <footer class="entry-footer">
           <?php
           if(is_user_logged_in()){
             echo '<p>';
                edit_post_link( __('Edit','alpha'),'<span class="meta-edit">','</span>');
             echo '</p>';
           }
        ?>
        </footer>
      </article>
      <?php comments_template();?>
   <?php endwhile;  ?>
</div>


<?php get_sidebar(); ?>

<?php get_footer(); ?>
