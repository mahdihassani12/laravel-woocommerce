
<?php
/*

----------------------------
  1.0 define constant
----------------------------
*/

define('THEMEROOT',get_stylesheet_directory_uri() );
define('IMAGES',THEMEROOT.'/images');
define('SCRIPTS',THEMEROOT.'/js');
define('FRAMEWORK',get_template_directory().'/framework');

/*
--------------------------
 2.0  load framework
--------------------------
*/

require_once(FRAMEWORK.'/init.php');


/*
--------------------
 3.0 Set up the content width value based on the theme design.
-------------------
*/

if(!isset($content_width)){
	$content_width=800;
}

/*
-----------------------------------------------
 4.0  set up theme default and register various supported features.
-----------------------------------------------
*/

if(! function_exists('alpha_setup')){
	function alpha_setup(){
      $lang_dir=THEMEROOT.'/languages';
      load_theme_textdomain('alpha',$lang_dir);


      // add support for post format
			add_theme_support( 'post-formats',
		 array(
			 'gallery',
			 'link',
			 'image',
			 'quote',
			 'video',
			 'audio'
		 )
	 );

        // add support for automatic feed link
       	add_theme_support('automatic-feed-links');


       	// add support for post exif_thumbnail
       	add_theme_support('thumbnails');


       	// Register nav Menu
       	register_nav_menus(
          array(
           'main-menu'=>__('Main Menu','alpha')
          )
       	);
	}

	add_action('after_setup_theme','alpha_setup');
}


//display meta information of a post
if(! function_exists('alpha_post_meta')){
	function alpha_post_meta(){
		echo "<ul class='list-inline entry-meta'>";
		  if(get_post_type()==='post'){
				if(is_sticky()){
					echo "<li class='meta-featured-post'><i class='fa fa-thumb-tack'></i>".__('Sticky','alpha')."</li>";
				}

    printf(
			'<li class="meta-author"><a href="%1$s" rel="author">%2$s</a></li>',
			esc_url(get_author_posts_url(get_the_author_meta("ID"))),
			get_the_author()
   );

    echo '<li class="meta-date">'.get_the_date().'</li>';


     $category_list=get_the_category_list('',', ');
		 if($category_list){
			 echo '<li class="meta-categories">'.$category_list.'</li>';
		 }

		 $tags_list=get_the_tag_list(', ');
		 if($tags_list){
			 echo '<li class="meta-categories">'.$tags_list.'</li>';
		 }

	if(comments_open()):
		 echo '<li>';
		 echo '<span class="meta-reply">';
		 comments_popup_link(__('Leave a comment','alpha'),__('One comment','alpha'),__('View all % commetns','alpha'));
		 echo '</span>';
		 echo '</li>';
	 endif;
		}
		if(is_user_logged_in()){
			echo '<li>';
			   edit_post_link( __('Edit','alpha'),'<span class="meta-edit">','</span>');
			echo '</li>';
		}
	}
}

// displya the next and previous post
if(! function_exists('alpha_paging_nav')){
	function alpha_paging_nav(){
		 echo "<ul>";
        if(get_previous_posts_link()){
            echo "<li>";
              previous_posts_link(__('Newer posts &rarr;','alpha'));
						echo "</li>";
					}


				if(get_next_posts_link()){
            echo "<li>";
              next_posts_link(__('old posts &rarr;','alpha'));
						echo "</li>";
					}


		 echo "</ul>";
	}
}



// register the widget area or sidebar
if(!function_exists('alpha_widget_init')){
   function alpha_widget_init(){
		  if(function_exists('register_sidebar')){
				register_sidebar(
					array(
             'name'=>__('Main Widget Area','alpha'),
						 'id'=>'sidebar-1',
						 'description'=>__('Apears on posts and pages','alpha'),
						 'before_widget'=>'<div id="%1$s" class="widget %2$s">',
						 'after_widget'=>'</div>',
						 'before_title'=>'<h5 class="widget-title">',
						 'after_title'=>'</h5>',
					)
				);


				register_sidebar(
					array(
             'name'=>__('Footer Widget Area','alpha'),
						 'id'=>'sidebar-2',
						 'description'=>__('Apears on the footer','alpha'),
						 'before_widget'=>'<div id="%1$s" class="widget col-sm-3 %2$s">',
						 'after_widget'=>'</div>',
						 'before_title'=>'<h5 class="widget-title">',
						 'after_title'=>'</h5>',
					)
				);
			}
	 }

	 add_action('widgets_init','alpha_widget_init');
}


?>
